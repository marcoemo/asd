import { http, HttpResponse } from 'msw';
import { MICROSERVICES } from "src/services/api.config.ts";

export const handlers = [
  // Auth endpoints
  http.post(`${MICROSERVICES.AUTH}/login`, async ({ request }) => {
    const body = await request.json();
    if (body.email === 'admin@test.com' && body.contrasena === 'admin123') {
      return HttpResponse.json({
        success: true,
        message: 'Login exitoso'
      });
    }
    return HttpResponse.json(
      { success: false, message: 'Credenciales incorrectas' },
      { status: 401 }
    );
  }),

  http.post(`${MICROSERVICES.AUTH}/register`, async ({ request }) => {
    const body = await request.json();
    return HttpResponse.json({
      id: 1,
      nombre: body.nombre,
      email: body.email,
      telefono: body.telefono,
      isAdmin: false
    });
  }),

  http.get(`${MICROSERVICES.AUTH}/usuario/correo/:email`, () => {
    return HttpResponse.json({
      id: 1,
      nombre: 'Admin',
      email: 'admin@test.com',
      telefono: '+56912345678',
      isAdmin: true
    });
  }),

  // Productos endpoints
  http.get(`${MICROSERVICES.CATALOGO}`, () => {
    return HttpResponse.json([
      {
        id: 1,
        nombre: 'Alimento Premium',
        descripcion: 'Alimento de calidad',
        precio: 28990,
        categoria: 'Alimento',
        imagen: 'test.jpg'
      }
    ]);
  }),

  // Carrito endpoints
  http.get(`${MICROSERVICES.CARRITO}/usuario/:id`, () => {
    return HttpResponse.json([]);
  }),

  http.post(`${MICROSERVICES.CARRITO}/agregar`, async ({ request }) => {
    const body = await request.json();
    return HttpResponse.json({
      id: 1,
      usuarioId: body.usuarioId,
      productoId: body.productoId,
      productoNombre: 'Producto Test',
      productoPrecio: 10000,
      cantidad: body.cantidad,
      imageUrl: 'test.jpg'
    });
  }),

  // Animales endpoints
  http.get(`${MICROSERVICES.ANIMALES}`, () => {
    return HttpResponse.json([
      {
        id: 1,
        nombre: 'Luna',
        especie: 'Perro',
        raza: 'Labrador',
        edad: '2 años',
        descripcion: 'Perro amigable',
        imagen: 'test.jpg',
        isAdoptado: false
      }
    ]);
  })
];