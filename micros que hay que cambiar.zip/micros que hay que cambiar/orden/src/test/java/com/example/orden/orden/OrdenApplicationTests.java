package com.example.orden.orden;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdenApplicationTests {

	@Test
	void contextLoads() {
	}

}
