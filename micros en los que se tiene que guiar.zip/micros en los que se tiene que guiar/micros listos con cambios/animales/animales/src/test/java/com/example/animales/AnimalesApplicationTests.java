package com.example.animales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
