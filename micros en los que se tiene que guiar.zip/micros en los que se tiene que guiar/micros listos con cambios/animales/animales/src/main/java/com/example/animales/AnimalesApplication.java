package com.example.animales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimalesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimalesApplication.class, args);
	}

}
//json para eliminar: url: http://localhost:8093/animales/5?emailAdmin=admin@amilimetros.cl