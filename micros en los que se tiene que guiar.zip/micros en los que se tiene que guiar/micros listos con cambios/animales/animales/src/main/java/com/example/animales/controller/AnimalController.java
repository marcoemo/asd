package com.example.animales.controller;

import com.example.animales.Client.UsuarioClient;
import com.example.animales.Client.UsuarioResponse;
import com.example.animales.model.Animal;
import com.example.animales.service.AnimalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Encoding;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/animales")
@Tag(
        name = "Animales",
        description = "Endpoints para gestionar animales, incluyendo filtros, búsqueda, imágenes y operaciones restringidas a administradores."
)
public class AnimalController {

    private final AnimalService animalService;
    private final UsuarioClient usuarioClient;

    public AnimalController(AnimalService animalService, UsuarioClient usuarioClient) {
        this.animalService = animalService;
        this.usuarioClient = usuarioClient;
    }

    // ============================
    // OBTENER TODOS
    // ============================
    @Operation(
            summary = "Listar todos los animales",
            description = "Retorna la lista completa de animales registrados en el sistema, incluyendo adoptados y no adoptados."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente"),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping
    public List<Animal> obtenerTodos() {
        return animalService.obtenerTodos();
    }

    // ============================
    // OBTENER DISPONIBLES (no adoptados)
    // ============================
    @Operation(
            summary = "Listar animales disponibles",
            description = "Retorna únicamente los animales que NO están marcados como adoptados."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Listado de disponibles obtenido correctamente"),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/disponibles")
    public List<Animal> obtenerDisponibles() {
        return animalService.obtenerDisponibles();
    }

    // ============================
    // OBTENER ADOPTADOS
    // ============================
    @Operation(
            summary = "Listar animales adoptados",
            description = "Retorna únicamente los animales que están marcados como adoptados."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Listado de adoptados obtenido correctamente"),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/adoptados")
    public List<Animal> obtenerAdoptados() {
        return animalService.obtenerAdoptados();
    }

    // ============================
    // OBTENER POR ID
    // ============================
    @Operation(
            summary = "Obtener animal por ID",
            description = "Busca un animal por su identificador. Si no existe, retorna 404."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Animal encontrado",
                    content = @Content(schema = @Schema(implementation = Animal.class))
            ),
            @ApiResponse(responseCode = "404", description = "Animal no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Animal> obtenerPorId(
            @Parameter(description = "ID del animal", example = "1")
            @PathVariable Long id
    ) {
        Animal animal = animalService.obtenerPorId(id);
        return animal != null ? ResponseEntity.ok(animal) : ResponseEntity.notFound().build();
    }

    // ============================
    // OBTENER POR ESPECIE
    // ============================
    @Operation(
            summary = "Filtrar animales por especie",
            description = "Retorna animales según la especie indicada (por ejemplo: perro, gato)."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Listado filtrado obtenido correctamente"),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/especie/{especie}")
    public List<Animal> obtenerPorEspecie(
            @Parameter(description = "Especie a filtrar", example = "gato")
            @PathVariable String especie
    ) {
        return animalService.obtenerPorEspecie(especie);
    }

    // ============================
    // BUSCAR POR NOMBRE
    // ============================
    @Operation(
            summary = "Buscar animales por nombre",
            description = "Retorna una lista de animales cuyo nombre coincide parcial o totalmente con el parámetro entregado."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Búsqueda realizada correctamente"),
            @ApiResponse(responseCode = "400", description = "Parámetro de búsqueda inválido")
    })
    @GetMapping("/buscar")
    public List<Animal> buscarPorNombre(
            @Parameter(description = "Texto a buscar en el nombre", example = "Luna")
            @RequestParam String nombre
    ) {
        return animalService.buscarPorNombre(nombre);
    }

    // ============================
    // VALIDAR ADMIN
    // ============================
    private boolean esAdmin(String correo) {
        UsuarioResponse user = usuarioClient.buscarPorCorreo(correo);
        return user != null && Boolean.TRUE.equals(user.getIsAdmin());
    }

    // ============================
    // CREAR ANIMAL (solo admin)
    // ============================
    @Operation(
            summary = "Crear animal (solo admin)",
            description = "Crea un animal nuevo. Requiere que el correo enviado en 'emailAdmin' pertenezca a un usuario administrador."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Animal creado correctamente",
                    content = @Content(schema = @Schema(implementation = Animal.class))),
            @ApiResponse(responseCode = "400", description = "Validación fallida (campos obligatorios)"),
            @ApiResponse(responseCode = "403", description = "No autorizado: el usuario no es admin")
    })
    @PostMapping
    public ResponseEntity<?> crear(
            @RequestBody(
                    description = "Body con datos del animal y el email del administrador",
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = CrearActualizarAnimalBody.class)
                    )
            )
            @org.springframework.web.bind.annotation.RequestBody Map<String, Object> body
    ) {

        String emailAdmin = (String) body.get("emailAdmin");

        if (!esAdmin(emailAdmin)) {
            return ResponseEntity.status(403).body("No tienes permisos para agregar animales");
        }

        if (body.get("nombre") == null || ((String) body.get("nombre")).isBlank())
            return ResponseEntity.badRequest().body("El nombre no puede estar vacío");

        if (body.get("especie") == null || ((String) body.get("especie")).isBlank())
            return ResponseEntity.badRequest().body("La especie no puede estar vacía");

        if (body.get("raza") == null || ((String) body.get("raza")).isBlank())
            return ResponseEntity.badRequest().body("La raza no puede estar vacía");

        if (body.get("descripcion") == null || ((String) body.get("descripcion")).isBlank())
            return ResponseEntity.badRequest().body("La descripción no puede estar vacía");

        if (body.get("edad") == null || ((String) body.get("edad")).isBlank())
            return ResponseEntity.badRequest().body("La edad es obligatoria");

        Animal animal = Animal.builder()
                .nombre((String) body.get("nombre"))
                .especie((String) body.get("especie"))
                .raza((String) body.get("raza"))
                .edad((String) body.get("edad"))
                .descripcion((String) body.get("descripcion"))
                .isAdoptado(false)
                .build();

        return ResponseEntity.status(201).body(animalService.crear(animal));
    }

    // ============================
    // ACTUALIZAR ANIMAL (solo admin)
    // ============================
    @Operation(
            summary = "Actualizar animal (solo admin)",
            description = "Actualiza los datos del animal indicado por ID. Requiere 'emailAdmin' válido como administrador."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Animal actualizado correctamente",
                    content = @Content(schema = @Schema(implementation = Animal.class))),
            @ApiResponse(responseCode = "400", description = "Validación fallida (campos obligatorios)"),
            @ApiResponse(responseCode = "403", description = "No autorizado: el usuario no es admin"),
            @ApiResponse(responseCode = "404", description = "Animal no encontrado")
    })
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @Parameter(description = "ID del animal a actualizar", example = "2")
            @PathVariable Long id,
            @RequestBody(
                    description = "Body con datos del animal, bandera isAdoptado opcional y email del administrador",
                    required = true,
                    content = @Content(schema = @Schema(implementation = CrearActualizarAnimalBody.class))
            )
            @org.springframework.web.bind.annotation.RequestBody Map<String, Object> body
    ) {
        String emailAdmin = (String) body.get("emailAdmin");

        if (!esAdmin(emailAdmin)) {
            return ResponseEntity.status(403).body("No tienes permisos para actualizar animales");
        }

        if (body.get("nombre") == null || ((String) body.get("nombre")).isBlank())
            return ResponseEntity.badRequest().body("El nombre no puede estar vacío");

        if (body.get("especie") == null || ((String) body.get("especie")).isBlank())
            return ResponseEntity.badRequest().body("La especie no puede estar vacía");

        if (body.get("raza") == null || ((String) body.get("raza")).isBlank())
            return ResponseEntity.badRequest().body("La raza no puede estar vacía");

        if (body.get("descripcion") == null || ((String) body.get("descripcion")).isBlank())
            return ResponseEntity.badRequest().body("La descripción no puede estar vacía");

        if (body.get("edad") == null || ((String) body.get("edad")).isBlank())
            return ResponseEntity.badRequest().body("La edad es obligatoria");

        Boolean isAdoptado = body.get("isAdoptado") != null
                ? Boolean.valueOf(body.get("isAdoptado").toString())
                : false;

        Animal animal = Animal.builder()
                .nombre((String) body.get("nombre"))
                .especie((String) body.get("especie"))
                .raza((String) body.get("raza"))
                .edad((String) body.get("edad"))
                .descripcion((String) body.get("descripcion"))
                .isAdoptado(isAdoptado)
                .build();

        Animal actualizado = animalService.actualizar(id, animal);
        return actualizado != null ? ResponseEntity.ok(actualizado) : ResponseEntity.notFound().build();
    }

    // ============================
    // ACTUALIZAR IMAGEN (solo admin)
    // ============================
    @Operation(
            summary = "Actualizar imagen del animal (solo admin)",
            description = "Actualiza la imagen asociada a un animal. Recibe multipart/form-data con el archivo y el email del admin."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Imagen actualizada correctamente"),
            @ApiResponse(responseCode = "400", description = "Error al leer la imagen o request inválido"),
            @ApiResponse(responseCode = "403", description = "No autorizado: el usuario no es admin"),
            @ApiResponse(responseCode = "404", description = "Animal no encontrado")
    })
    @PostMapping(value = "/{id}/imagen", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> actualizarImagen(
            @Parameter(description = "ID del animal", example = "3")
            @PathVariable Long id,
            @Parameter(
                    description = "Archivo de imagen",
                    required = true,
                    content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE,
                            schema = @Schema(type = "string", format = "binary"),
                            encoding = @Encoding(name = "file", contentType = "image/*"))
            )
            @RequestParam("file") MultipartFile file,
            @Parameter(description = "Correo del administrador que ejecuta la acción", example = "admin@amilimetros.cl")
            @RequestParam("emailAdmin") String emailAdmin
    ) {
        if (!esAdmin(emailAdmin)) {
            return ResponseEntity.status(403).body("No tienes permisos para actualizar imágenes");
        }

        try {
            boolean ok = animalService.actualizarImagen(id, file.getBytes());
            return ok ? ResponseEntity.ok("Imagen actualizada correctamente")
                    : ResponseEntity.notFound().build();
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Error al leer la imagen");
        }
    }

    // ============================
    // OBTENER IMAGEN
    // ============================
    @Operation(
            summary = "Obtener imagen del animal",
            description = "Retorna la imagen asociada al animal (JPEG/PNG/GIF) como arreglo de bytes."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Imagen obtenida correctamente",
                    content = @Content(mediaType = "image/jpeg")),
            @ApiResponse(responseCode = "404", description = "Animal no encontrado o no tiene imagen")
    })
    @GetMapping(
            value = "/{id}/imagen",
            produces = {
                    MediaType.IMAGE_JPEG_VALUE,
                    MediaType.IMAGE_PNG_VALUE,
                    MediaType.IMAGE_GIF_VALUE
            }
    )
    public ResponseEntity<byte[]> obtenerImagen(
            @Parameter(description = "ID del animal", example = "3")
            @PathVariable Long id
    ) {
        Animal animal = animalService.obtenerPorId(id);

        if (animal == null || animal.getImagen() == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(animal.getImagen());
    }

    // ============================
    // MARCAR COMO ADOPTADO (solo admin)
    // ============================
    @Operation(
            summary = "Marcar animal como adoptado (solo admin)",
            description = "Marca el animal como adoptado. Requiere emailAdmin que pertenezca a un administrador."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Animal marcado como adoptado"),
            @ApiResponse(responseCode = "403", description = "No autorizado: el usuario no es admin"),
            @ApiResponse(responseCode = "404", description = "Animal no encontrado")
    })
    @PutMapping("/{id}/adoptar")
    public ResponseEntity<?> marcarComoAdoptado(
            @Parameter(description = "ID del animal", example = "4")
            @PathVariable Long id,
            @Parameter(description = "Correo del administrador", example = "admin@amilimetros.cl")
            @RequestParam("emailAdmin") String emailAdmin
    ) {
        if (!esAdmin(emailAdmin)) {
            return ResponseEntity.status(403).body("No tienes permisos para marcar animales como adoptados");
        }

        boolean ok = animalService.marcarComoAdoptado(id);
        return ok ? ResponseEntity.ok("Animal marcado como adoptado")
                : ResponseEntity.notFound().build();
    }

    // ============================
    // ELIMINAR ANIMAL (solo admin)
    // ============================
    @Operation(
            summary = "Eliminar animal (solo admin)",
            description = "Elimina un animal por ID. Requiere emailAdmin válido como administrador."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Animal eliminado correctamente"),
            @ApiResponse(responseCode = "403", description = "No autorizado: el usuario no es admin"),
            @ApiResponse(responseCode = "404", description = "Animal no encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(
            @Parameter(description = "ID del animal", example = "5")
            @PathVariable Long id,
            @Parameter(description = "Correo del administrador", example = "admin@amilimetros.cl")
            @RequestParam("emailAdmin") String emailAdmin
    ) {
        if (!esAdmin(emailAdmin)) {
            return ResponseEntity.status(403).body("No tienes permisos para eliminar animales");
        }

        return animalService.eliminar(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }

    // ============================
    // SCHEMA PARA DOCUMENTAR EL BODY (Map) EN SWAGGER
    // ============================
    @Schema(
            name = "CrearActualizarAnimalBody",
            description = "Estructura esperada del body para crear/actualizar un animal. Se utiliza Map en el controller, pero Swagger mostrará este esquema."
    )
    public static class CrearActualizarAnimalBody {

        @Schema(description = "Correo del administrador que ejecuta la acción", example = "admin@amilimetros.cl", requiredMode = Schema.RequiredMode.REQUIRED)
        public String emailAdmin;

        @Schema(description = "Nombre del animal", example = "Luna", requiredMode = Schema.RequiredMode.REQUIRED)
        public String nombre;

        @Schema(description = "Especie del animal", example = "gato", requiredMode = Schema.RequiredMode.REQUIRED)
        public String especie;

        @Schema(description = "Raza del animal", example = "mestizo", requiredMode = Schema.RequiredMode.REQUIRED)
        public String raza;

        @Schema(description = "Edad del animal (texto según tu modelo)", example = "2 años", requiredMode = Schema.RequiredMode.REQUIRED)
        public String edad;

        @Schema(description = "Descripción del animal", example = "Cariñosa, juguetona y sociable", requiredMode = Schema.RequiredMode.REQUIRED)
        public String descripcion;

        @Schema(description = "Indica si está adoptado (solo al actualizar)", example = "false")
        public Boolean isAdoptado;
    }
}
