package com.example.carrito.service;

import com.example.carrito.Client.ProductoClient;
import com.example.carrito.Client.UsuarioClient;
import com.example.carrito.model.ItemCarrito;
import com.example.carrito.repository.ItemCarritoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class CarritoServiceTest {

    @Mock
    private ItemCarritoRepository itemCarritoRepository;

    @Mock
    private ProductoClient productoClient;

    @Mock
    private UsuarioClient usuarioClient;

    @InjectMocks
    private CarritoService carritoService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    // =========================
    // obtenerCarritoPorUsuario
    // =========================

    @Test
    void obtenerCarritoPorUsuario_ok_retornaLista() {
        Long usuarioId = 1L;

        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(Map.of("id", usuarioId));
        when(itemCarritoRepository.findByUsuarioId(usuarioId)).thenReturn(List.of(new ItemCarrito()));

        List<ItemCarrito> res = carritoService.obtenerCarritoPorUsuario(usuarioId);

        assertNotNull(res);
        assertEquals(1, res.size());
        verify(usuarioClient).obtenerUsuarioPorId(usuarioId);
        verify(itemCarritoRepository).findByUsuarioId(usuarioId);
    }

    @Test
    void obtenerCarritoPorUsuario_lanzaException_siUsuarioNoExiste() {
        Long usuarioId = 1L;

        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(null);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> carritoService.obtenerCarritoPorUsuario(usuarioId));

        assertEquals("Usuario no encontrado", ex.getMessage());
        verify(usuarioClient).obtenerUsuarioPorId(usuarioId);
        verify(itemCarritoRepository, never()).findByUsuarioId(anyLong());
    }

    // =========================
    // agregarAlCarrito
    // =========================

    @Test
    void agregarAlCarrito_lanzaException_siUsuarioNoExiste() {
        when(usuarioClient.obtenerUsuarioPorId(1L)).thenReturn(null);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> carritoService.agregarAlCarrito(1L, 10L, 1));

        assertEquals("Usuario no encontrado", ex.getMessage());
        verify(productoClient, never()).obtenerProductoPorId(anyLong());
        verify(itemCarritoRepository, never()).save(any());
    }

    @Test
    void agregarAlCarrito_lanzaException_siProductoNoExiste() {
        when(usuarioClient.obtenerUsuarioPorId(1L)).thenReturn(Map.of("id", 1L));
        when(productoClient.obtenerProductoPorId(10L)).thenReturn(null);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> carritoService.agregarAlCarrito(1L, 10L, 1));

        assertEquals("Producto no encontrado", ex.getMessage());
        verify(itemCarritoRepository, never()).save(any());
    }

    @Test
    void agregarAlCarrito_siItemExiste_actualizaCantidad() {
        Long usuarioId = 1L;
        Long productoId = 10L;

        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(Map.of("id", usuarioId));
        when(productoClient.obtenerProductoPorId(productoId)).thenReturn(Map.of("id", productoId, "nombre", "X", "precio", 1500.0));

        ItemCarrito existente = new ItemCarrito();
        existente.setUsuarioId(usuarioId);
        existente.setProductoId(productoId);
        existente.setCantidad(2);

        when(itemCarritoRepository.findByUsuarioIdAndProductoId(usuarioId, productoId))
                .thenReturn(Optional.of(existente));

        when(itemCarritoRepository.save(any(ItemCarrito.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        ItemCarrito res = carritoService.agregarAlCarrito(usuarioId, productoId, 3);

        assertEquals(5, res.getCantidad());
        verify(itemCarritoRepository).save(existente);
    }

    @Test
    void agregarAlCarrito_siNoExiste_creaNuevoItem_precioDouble() {
        Long usuarioId = 1L;
        Long productoId = 10L;

        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(Map.of("id", usuarioId));

        Map<String, Object> producto = new HashMap<>();
        producto.put("id", productoId);
        producto.put("nombre", "Alimento");
        producto.put("precio", 7990.0); // Double
        producto.put("imageUrl", "http://img");

        when(productoClient.obtenerProductoPorId(productoId)).thenReturn(producto);

        when(itemCarritoRepository.findByUsuarioIdAndProductoId(usuarioId, productoId))
                .thenReturn(Optional.empty());

        when(itemCarritoRepository.save(any(ItemCarrito.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        ItemCarrito res = carritoService.agregarAlCarrito(usuarioId, productoId, 2);

        assertEquals(usuarioId, res.getUsuarioId());
        assertEquals(productoId, res.getProductoId());
        assertEquals("Alimento", res.getProductoNombre());
        assertEquals(7990.0, res.getProductoPrecio());
        assertEquals(2, res.getCantidad());
        assertEquals("http://img", res.getImageUrl());

        verify(itemCarritoRepository).save(any(ItemCarrito.class));
    }

    @Test
    void agregarAlCarrito_siNoExiste_creaNuevoItem_precioInteger() {
        Long usuarioId = 1L;
        Long productoId = 10L;

        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(Map.of("id", usuarioId));

        Map<String, Object> producto = new HashMap<>();
        producto.put("nombre", "Collar");
        producto.put("precio", 2500); // Integer
        producto.put("imageUrl", "img");

        when(productoClient.obtenerProductoPorId(productoId)).thenReturn(producto);

        when(itemCarritoRepository.findByUsuarioIdAndProductoId(usuarioId, productoId))
                .thenReturn(Optional.empty());

        when(itemCarritoRepository.save(any(ItemCarrito.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        ItemCarrito res = carritoService.agregarAlCarrito(usuarioId, productoId, 1);

        assertEquals(2500.0, res.getProductoPrecio());
        verify(itemCarritoRepository).save(any(ItemCarrito.class));
    }

    // =========================
    // actualizarCantidad
    // =========================

    @Test
    void actualizarCantidad_retornaEmpty_siNoExiste() {
        when(itemCarritoRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<ItemCarrito> res = carritoService.actualizarCantidad(99L, 5);

        assertTrue(res.isEmpty());
        verify(itemCarritoRepository, never()).save(any());
        verify(itemCarritoRepository, never()).delete(any());
    }

    @Test
    void actualizarCantidad_siNuevaCantidadMenorIgualCero_eliminaYEmpty() {
        ItemCarrito item = new ItemCarrito();
        item.setCantidad(2);

        when(itemCarritoRepository.findById(10L)).thenReturn(Optional.of(item));

        Optional<ItemCarrito> res = carritoService.actualizarCantidad(10L, 0);

        assertTrue(res.isEmpty());
        verify(itemCarritoRepository).delete(item);
        verify(itemCarritoRepository, never()).save(any());
    }

    @Test
    void actualizarCantidad_ok_actualizaYGuarda() {
        ItemCarrito item = new ItemCarrito();
        item.setCantidad(2);

        when(itemCarritoRepository.findById(10L)).thenReturn(Optional.of(item));
        when(itemCarritoRepository.save(any(ItemCarrito.class))).thenAnswer(inv -> inv.getArgument(0));

        Optional<ItemCarrito> res = carritoService.actualizarCantidad(10L, 7);

        assertTrue(res.isPresent());
        assertEquals(7, res.get().getCantidad());
        verify(itemCarritoRepository).save(item);
    }

    // =========================
    // eliminarItem
    // =========================

    @Test
    void eliminarItem_true_siExiste() {
        when(itemCarritoRepository.existsById(10L)).thenReturn(true);

        boolean ok = carritoService.eliminarItem(10L);

        assertTrue(ok);
        verify(itemCarritoRepository).deleteById(10L);
    }

    @Test
    void eliminarItem_false_siNoExiste() {
        when(itemCarritoRepository.existsById(10L)).thenReturn(false);

        boolean ok = carritoService.eliminarItem(10L);

        assertFalse(ok);
        verify(itemCarritoRepository, never()).deleteById(anyLong());
    }

    // =========================
    // vaciarCarrito
    // =========================

    @Test
    void vaciarCarrito_ok_eliminaPorUsuario() {
        Long usuarioId = 1L;
        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(Map.of("id", usuarioId));

        doNothing().when(itemCarritoRepository).deleteByUsuarioId(usuarioId);

        carritoService.vaciarCarrito(usuarioId);

        verify(itemCarritoRepository).deleteByUsuarioId(usuarioId);
    }

    @Test
    void vaciarCarrito_lanzaException_siUsuarioNoExiste() {
        Long usuarioId = 1L;
        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(null);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> carritoService.vaciarCarrito(usuarioId));

        assertEquals("Usuario no encontrado", ex.getMessage());
        verify(itemCarritoRepository, never()).deleteByUsuarioId(anyLong());
    }

    // =========================
    // calcularTotal
    // =========================

    @Test
    void calcularTotal_ok_retorna0_siRepoRetornaNull() {
        Long usuarioId = 1L;
        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(Map.of("id", usuarioId));
        when(itemCarritoRepository.calcularTotal(usuarioId)).thenReturn(null);

        Double total = carritoService.calcularTotal(usuarioId);

        assertEquals(0.0, total);
        verify(itemCarritoRepository).calcularTotal(usuarioId);
    }

    @Test
    void calcularTotal_ok_retornaTotalDelRepo() {
        Long usuarioId = 1L;
        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(Map.of("id", usuarioId));
        when(itemCarritoRepository.calcularTotal(usuarioId)).thenReturn(15000.0);

        Double total = carritoService.calcularTotal(usuarioId);

        assertEquals(15000.0, total);
        verify(itemCarritoRepository).calcularTotal(usuarioId);
    }

    @Test
    void calcularTotal_lanzaException_siUsuarioNoExiste() {
        when(usuarioClient.obtenerUsuarioPorId(1L)).thenReturn(null);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> carritoService.calcularTotal(1L));

        assertEquals("Usuario no encontrado", ex.getMessage());
        verify(itemCarritoRepository, never()).calcularTotal(anyLong());
    }

    // =========================
    // obtenerDetallesCarrito
    // =========================

    @Test
    void obtenerDetallesCarrito_ok_armadoCorrecto() {
        Long usuarioId = 1L;

        Map<String, Object> usuario = Map.of("id", usuarioId, "nombre", "Lore");
        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(usuario);

        List<ItemCarrito> items = List.of(new ItemCarrito(), new ItemCarrito());
        when(itemCarritoRepository.findByUsuarioId(usuarioId)).thenReturn(items);

        when(itemCarritoRepository.calcularTotal(usuarioId)).thenReturn(20000.0);

        Map<String, Object> detalles = carritoService.obtenerDetallesCarrito(usuarioId);

        assertEquals(usuario, detalles.get("usuario"));
        assertEquals(items, detalles.get("items"));
        assertEquals(20000.0, (Double) detalles.get("total"));
        assertEquals(2, detalles.get("cantidadItems"));
    }

    @Test
    void obtenerDetallesCarrito_lanzaException_siUsuarioNoExiste() {
        Long usuarioId = 1L;
        when(usuarioClient.obtenerUsuarioPorId(usuarioId)).thenReturn(null);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> carritoService.obtenerDetallesCarrito(usuarioId));

        assertEquals("Usuario no encontrado", ex.getMessage());
        verify(itemCarritoRepository, never()).findByUsuarioId(anyLong());
    }
}
