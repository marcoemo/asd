package com.example.carrito.controller;

import com.example.carrito.model.ItemCarrito;
import com.example.carrito.service.CarritoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CarritoController.class)
class CarritoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CarritoService carritoService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void obtenerCarrito_200() throws Exception {
        Long usuarioId = 1L;

        ItemCarrito item = new ItemCarrito();
        // Si tu modelo tiene setters, setéalos; si no, no importa para este test básico.
        // item.setId(10L);

        when(carritoService.obtenerCarritoPorUsuario(usuarioId)).thenReturn(List.of(item));

        mockMvc.perform(get("/carrito/usuario/{usuarioId}", usuarioId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));

        verify(carritoService).obtenerCarritoPorUsuario(usuarioId);
    }

    @Test
    void obtenerCarrito_400_cuandoServiceLanzaIllegalArgument() throws Exception {
        Long usuarioId = 1L;

        when(carritoService.obtenerCarritoPorUsuario(usuarioId))
                .thenThrow(new IllegalArgumentException("Usuario inválido"));

        mockMvc.perform(get("/carrito/usuario/{usuarioId}", usuarioId))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("Usuario inválido"));
    }

    @Test
    void obtenerDetallesCarrito_200() throws Exception {
        Long usuarioId = 1L;

        when(carritoService.obtenerDetallesCarrito(usuarioId)).thenReturn(
                Map.of("usuarioId", usuarioId, "total", 15000.0, "items", List.of())
        );

        mockMvc.perform(get("/carrito/usuario/{usuarioId}/detalles", usuarioId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.usuarioId").value(1))
                .andExpect(jsonPath("$.total").value(15000.0));

        verify(carritoService).obtenerDetallesCarrito(usuarioId);
    }

    @Test
    void obtenerDetallesCarrito_400_cuandoServiceLanzaIllegalArgument() throws Exception {
        Long usuarioId = 1L;

        when(carritoService.obtenerDetallesCarrito(usuarioId))
                .thenThrow(new IllegalArgumentException("Carrito no existe"));

        mockMvc.perform(get("/carrito/usuario/{usuarioId}/detalles", usuarioId))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("Carrito no existe"));
    }

    @Test
    void agregarAlCarrito_201() throws Exception {
        ItemCarrito item = new ItemCarrito();
        when(carritoService.agregarAlCarrito(eq(1L), eq(10L), eq(2))).thenReturn(item);

        Map<String, Object> body = Map.of(
                "usuarioId", 1,
                "productoId", 10,
                "cantidad", 2
        );

        mockMvc.perform(post("/carrito/agregar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isCreated());

        verify(carritoService).agregarAlCarrito(1L, 10L, 2);
    }

    @Test
    void agregarAlCarrito_400_cuandoServiceLanzaIllegalArgument() throws Exception {
        when(carritoService.agregarAlCarrito(anyLong(), anyLong(), anyInt()))
                .thenThrow(new IllegalArgumentException("Cantidad inválida"));

        Map<String, Object> body = Map.of(
                "usuarioId", 1,
                "productoId", 10,
                "cantidad", 0
        );

        mockMvc.perform(post("/carrito/agregar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("Cantidad inválida"));
    }

    @Test
    void actualizarCantidad_200_siExiste() throws Exception {
        Long itemId = 99L;

        ItemCarrito actualizado = new ItemCarrito();
        when(carritoService.actualizarCantidad(eq(itemId), eq(5)))
                .thenReturn(Optional.of(actualizado));

        Map<String, Integer> body = Map.of("cantidad", 5);

        mockMvc.perform(put("/carrito/item/{itemId}", itemId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isOk());

        verify(carritoService).actualizarCantidad(itemId, 5);
    }

    @Test
    void actualizarCantidad_404_siNoExiste() throws Exception {
        Long itemId = 99L;

        when(carritoService.actualizarCantidad(eq(itemId), eq(5)))
                .thenReturn(Optional.empty());

        Map<String, Integer> body = Map.of("cantidad", 5);

        mockMvc.perform(put("/carrito/item/{itemId}", itemId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isNotFound());

        verify(carritoService).actualizarCantidad(itemId, 5);
    }

    @Test
    void eliminarItem_204_siElimina() throws Exception {
        Long itemId = 10L;
        when(carritoService.eliminarItem(itemId)).thenReturn(true);

        mockMvc.perform(delete("/carrito/item/{itemId}", itemId))
                .andExpect(status().isNoContent());

        verify(carritoService).eliminarItem(itemId);
    }

    @Test
    void eliminarItem_404_siNoExiste() throws Exception {
        Long itemId = 10L;
        when(carritoService.eliminarItem(itemId)).thenReturn(false);

        mockMvc.perform(delete("/carrito/item/{itemId}", itemId))
                .andExpect(status().isNotFound());

        verify(carritoService).eliminarItem(itemId);
    }

    @Test
    void vaciarCarrito_204() throws Exception {
        Long usuarioId = 1L;

        doNothing().when(carritoService).vaciarCarrito(usuarioId);

        mockMvc.perform(delete("/carrito/usuario/{usuarioId}", usuarioId))
                .andExpect(status().isNoContent());

        verify(carritoService).vaciarCarrito(usuarioId);
    }

    @Test
    void vaciarCarrito_400_cuandoServiceLanzaIllegalArgument() throws Exception {
        Long usuarioId = 1L;

        doThrow(new IllegalArgumentException("Usuario inválido"))
                .when(carritoService).vaciarCarrito(usuarioId);

        mockMvc.perform(delete("/carrito/usuario/{usuarioId}", usuarioId))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("Usuario inválido"));
    }

    @Test
    void calcularTotal_200() throws Exception {
        Long usuarioId = 1L;
        when(carritoService.calcularTotal(usuarioId)).thenReturn(13000.0);

        mockMvc.perform(get("/carrito/usuario/{usuarioId}/total", usuarioId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(13000.0));

        verify(carritoService).calcularTotal(usuarioId);
    }

    @Test
    void calcularTotal_400_cuandoServiceLanzaIllegalArgument() throws Exception {
        Long usuarioId = 1L;
        when(carritoService.calcularTotal(usuarioId))
                .thenThrow(new IllegalArgumentException("Carrito vacío"));

        mockMvc.perform(get("/carrito/usuario/{usuarioId}/total", usuarioId))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("Carrito vacío"));
    }
}
