package com.example.catalogo.controller;

import com.example.catalogo.Client.UsuarioClient;
import com.example.catalogo.Client.UsuarioResponse;
import com.example.catalogo.model.Producto;
import com.example.catalogo.service.ProductoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Encoding;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/productos")
@Tag(
        name = "Productos",
        description = "Endpoints para gestionar el catálogo de productos, incluyendo filtros, búsqueda, imágenes y operaciones restringidas a administradores."
)
public class ProductoController {

    private final ProductoService productoService;
    private final UsuarioClient usuarioClient;

    public ProductoController(ProductoService productoService, UsuarioClient usuarioClient) {
        this.productoService = productoService;
        this.usuarioClient = usuarioClient;
    }

    // ============================
    // OBTENER TODOS
    // ============================
    @Operation(
            summary = "Listar productos",
            description = "Retorna la lista completa de productos registrados en el catálogo."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente"),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping
    public List<Producto> obtenerTodos() {
        return productoService.obtenerTodos();
    }

    // ============================
    // OBTENER POR ID
    // ============================
    @Operation(
            summary = "Obtener producto por ID",
            description = "Busca un producto por su identificador. Si no existe, retorna 404."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Producto encontrado",
                    content = @Content(schema = @Schema(implementation = Producto.class))
            ),
            @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerPorId(
            @Parameter(description = "ID del producto", example = "1")
            @PathVariable Long id
    ) {
        Producto producto = productoService.obtenerPorId(id);
        return producto != null ? ResponseEntity.ok(producto) : ResponseEntity.notFound().build();
    }

    // ============================
    // OBTENER POR CATEGORÍA
    // ============================
    @Operation(
            summary = "Filtrar productos por categoría",
            description = "Retorna una lista de productos filtrados por la categoría indicada."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Listado filtrado obtenido correctamente"),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/categoria/{categoria}")
    public List<Producto> obtenerPorCategoria(
            @Parameter(description = "Nombre de la categoría", example = "alimentos")
            @PathVariable String categoria
    ) {
        return productoService.obtenerPorCategoria(categoria);
    }

    // ============================
    // VALIDAR ADMIN
    // ============================
    private boolean esAdmin(String correo) {
        UsuarioResponse user = usuarioClient.buscarPorCorreo(correo);
        return user != null && "ADMIN".equalsIgnoreCase(user.getRol());
    }

    // ============================
    // CREAR PRODUCTO (solo admin)
    // ============================
    @Operation(
            summary = "Crear producto (solo admin)",
            description = "Crea un producto nuevo en el catálogo. Requiere que el correo enviado en 'emailAdmin' corresponda a un usuario con rol ADMIN."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "201",
                    description = "Producto creado correctamente",
                    content = @Content(schema = @Schema(implementation = Producto.class))
            ),
            @ApiResponse(responseCode = "400", description = "Validación fallida (campos obligatorios / precio mínimo)"),
            @ApiResponse(responseCode = "403", description = "No autorizado: el usuario no es admin")
    })
    @PostMapping
    public ResponseEntity<?> crear(
            @RequestBody(
                    description = "Body con datos del producto y el email del administrador",
                    required = true,
                    content = @Content(schema = @Schema(implementation = CrearActualizarProductoBody.class))
            )
            @org.springframework.web.bind.annotation.RequestBody Map<String, Object> body
    ) {

        String emailAdmin = (String) body.get("emailAdmin");

        if (!esAdmin(emailAdmin)) {
            return ResponseEntity.status(403).body("No tienes permisos para crear productos");
        }

        if (body.get("nombre") == null || ((String) body.get("nombre")).isBlank())
            return ResponseEntity.badRequest().body("El nombre no puede estar vacío");

        if (body.get("descripcion") == null || ((String) body.get("descripcion")).isBlank())
            return ResponseEntity.badRequest().body("La descripción no puede estar vacía");

        if (body.get("categoria") == null || ((String) body.get("categoria")).isBlank())
            return ResponseEntity.badRequest().body("La categoría no puede estar vacía");

        if (body.get("precio") == null)
            return ResponseEntity.badRequest().body("El precio es obligatorio");

        Double precio = Double.valueOf(body.get("precio").toString());
        if (precio < 1000)
            return ResponseEntity.badRequest().body("El precio mínimo es 1000 pesos");

        Producto producto = new Producto();
        producto.setNombre((String) body.get("nombre"));
        producto.setDescripcion((String) body.get("descripcion"));
        producto.setCategoria((String) body.get("categoria"));
        producto.setPrecio(precio);

        return ResponseEntity.status(201).body(productoService.crear(producto));
    }

    // ============================
    // ACTUALIZAR PRODUCTO (solo admin)
    // ============================
    @Operation(
            summary = "Actualizar producto (solo admin)",
            description = "Actualiza la información de un producto existente. Requiere 'emailAdmin' válido con rol ADMIN."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Producto actualizado correctamente",
                    content = @Content(schema = @Schema(implementation = Producto.class))
            ),
            @ApiResponse(responseCode = "400", description = "Validación fallida (campos obligatorios / precio mínimo)"),
            @ApiResponse(responseCode = "403", description = "No autorizado: el usuario no es admin"),
            @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    })
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @Parameter(description = "ID del producto a actualizar", example = "2")
            @PathVariable Long id,
            @RequestBody(
                    description = "Body con datos del producto y el email del administrador",
                    required = true,
                    content = @Content(schema = @Schema(implementation = CrearActualizarProductoBody.class))
            )
            @org.springframework.web.bind.annotation.RequestBody Map<String, Object> body
    ) {
        String emailAdmin = (String) body.get("emailAdmin");

        if (!esAdmin(emailAdmin)) {
            return ResponseEntity.status(403).body("No tienes permisos para actualizar productos");
        }

        if (body.get("nombre") == null || ((String) body.get("nombre")).isBlank())
            return ResponseEntity.badRequest().body("El nombre no puede estar vacío");

        if (body.get("descripcion") == null || ((String) body.get("descripcion")).isBlank())
            return ResponseEntity.badRequest().body("La descripción no puede estar vacía");

        if (body.get("categoria") == null || ((String) body.get("categoria")).isBlank())
            return ResponseEntity.badRequest().body("La categoría no puede estar vacía");

        if (body.get("precio") == null)
            return ResponseEntity.badRequest().body("El precio es obligatorio");

        Double precio = Double.valueOf(body.get("precio").toString());
        if (precio < 1000)
            return ResponseEntity.badRequest().body("El precio mínimo es 1000 pesos");

        Producto producto = new Producto();
        producto.setNombre((String) body.get("nombre"));
        producto.setDescripcion((String) body.get("descripcion"));
        producto.setCategoria((String) body.get("categoria"));
        producto.setPrecio(precio);

        Producto actualizado = productoService.actualizar(id, producto);
        return actualizado != null ? ResponseEntity.ok(actualizado) : ResponseEntity.notFound().build();
    }

    // ============================
    // ACTUALIZAR IMAGEN (solo admin)
    // ============================
    @Operation(
            summary = "Actualizar imagen del producto (solo admin)",
            description = "Actualiza la imagen asociada a un producto. Recibe multipart/form-data con el archivo y el email del admin."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Imagen actualizada correctamente"),
            @ApiResponse(responseCode = "400", description = "Error al leer la imagen o request inválido"),
            @ApiResponse(responseCode = "403", description = "No autorizado: el usuario no es admin"),
            @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    })
    @PostMapping(value = "/{id}/imagen", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> actualizarImagen(
            @Parameter(description = "ID del producto", example = "3")
            @PathVariable Long id,
            @Parameter(
                    description = "Archivo de imagen",
                    required = true,
                    content = @Content(
                            mediaType = MediaType.MULTIPART_FORM_DATA_VALUE,
                            schema = @Schema(type = "string", format = "binary"),
                            encoding = @Encoding(name = "file", contentType = "image/*")
                    )
            )
            @RequestParam("file") MultipartFile file,
            @Parameter(description = "Correo del administrador que ejecuta la acción", example = "admin@amilimetros.cl")
            @RequestParam("emailAdmin") String emailAdmin
    ) {
        if (!esAdmin(emailAdmin)) {
            return ResponseEntity.status(403).body("No tienes permisos para actualizar imágenes");
        }

        try {
            boolean ok = productoService.actualizarImagen(id, file.getBytes());
            return ok ? ResponseEntity.ok("Imagen actualizada correctamente")
                    : ResponseEntity.notFound().build();
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Error al leer la imagen");
        }
    }

    // ============================
    // OBTENER IMAGEN
    // ============================
    @Operation(
            summary = "Obtener imagen del producto",
            description = "Retorna la imagen asociada a un producto (JPEG/PNG/GIF) como arreglo de bytes."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Imagen obtenida correctamente",
                    content = @Content(mediaType = "image/jpeg")),
            @ApiResponse(responseCode = "404", description = "Producto no encontrado o no tiene imagen")
    })
    @GetMapping(
            value = "/{id}/imagen",
            produces = {
                    MediaType.IMAGE_JPEG_VALUE,
                    MediaType.IMAGE_PNG_VALUE,
                    MediaType.IMAGE_GIF_VALUE
            }
    )
    public ResponseEntity<byte[]> obtenerImagen(
            @Parameter(description = "ID del producto", example = "3")
            @PathVariable Long id
    ) {
        Producto producto = productoService.obtenerPorId(id);

        if (producto == null || producto.getImagen() == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(producto.getImagen());
    }

    // ============================
    // ELIMINAR PRODUCTO (solo admin)
    // ============================
    @Operation(
            summary = "Eliminar producto (solo admin)",
            description = "Elimina un producto por ID. Requiere emailAdmin válido con rol ADMIN."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Producto eliminado correctamente"),
            @ApiResponse(responseCode = "403", description = "No autorizado: el usuario no es admin"),
            @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(
            @Parameter(description = "ID del producto", example = "5")
            @PathVariable Long id,
            @Parameter(description = "Correo del administrador", example = "admin@amilimetros.cl")
            @RequestParam("emailAdmin") String emailAdmin
    ) {
        if (!esAdmin(emailAdmin)) {
            return ResponseEntity.status(403).body("No tienes permisos para eliminar productos");
        }

        return productoService.eliminar(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }

    // ============================
    // BUSCAR POR NOMBRE
    // ============================
    @Operation(
            summary = "Buscar productos por nombre",
            description = "Retorna productos cuyo nombre coincide parcial o totalmente con el texto ingresado."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Búsqueda realizada correctamente"),
            @ApiResponse(responseCode = "400", description = "Parámetro de búsqueda inválido")
    })
    @GetMapping("/buscar")
    public List<Producto> buscarPorNombre(
            @Parameter(description = "Texto a buscar en el nombre", example = "collar")
            @RequestParam String nombre
    ) {
        return productoService.buscarPorNombre(nombre);
    }

    // ============================
    // SCHEMA PARA DOCUMENTAR EL BODY (Map) EN SWAGGER
    // ============================
    @Schema(
            name = "CrearActualizarProductoBody",
            description = "Estructura esperada del body para crear/actualizar un producto. El controller usa Map, pero Swagger mostrará este esquema."
    )
    public static class CrearActualizarProductoBody {

        @Schema(description = "Correo del administrador (rol ADMIN)", example = "admin@amilimetros.cl", requiredMode = Schema.RequiredMode.REQUIRED)
        public String emailAdmin;

        @Schema(description = "Nombre del producto", example = "Alimento Premium Perro", requiredMode = Schema.RequiredMode.REQUIRED)
        public String nombre;

        @Schema(description = "Descripción del producto", example = "Alimento de alta calidad para perros adultos.", requiredMode = Schema.RequiredMode.REQUIRED)
        public String descripcion;

        @Schema(description = "Categoría del producto", example = "alimentos", requiredMode = Schema.RequiredMode.REQUIRED)
        public String categoria;

        @Schema(description = "Precio del producto (mínimo 1000)", example = "7990", requiredMode = Schema.RequiredMode.REQUIRED)
        public Double precio;
    }
}
