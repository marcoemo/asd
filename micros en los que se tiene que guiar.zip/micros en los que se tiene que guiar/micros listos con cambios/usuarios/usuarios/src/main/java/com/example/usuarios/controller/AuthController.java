package com.example.usuarios.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.usuarios.model.Usuario;
import com.example.usuarios.repository.UsuarioRepository;
import com.example.usuarios.service.AuthService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/auth")
@Tag(
        name = "Autenticación y Usuarios",
        description = "Endpoints para registro, login y gestión de usuarios."
)
public class AuthController {

    private final AuthService authService;
    private final UsuarioRepository usuarioRepository;

    public AuthController(AuthService authService, UsuarioRepository usuarioRepository) {
        this.authService = authService;
        this.usuarioRepository = usuarioRepository;
    }

    // =======================
    //      REGISTRO
    // =======================
    @Operation(
            summary = "Registrar usuario",
            description = "Registra un nuevo usuario en el sistema. Retorna el usuario registrado o un error de validación."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario registrado correctamente",
                    content = @Content(schema = @Schema(implementation = Usuario.class))
            ),
            @ApiResponse(responseCode = "400", description = "Error de validación o conflicto (ej: correo repetido)")
    })
    @PostMapping("/register")
    public ResponseEntity<?> registrar(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Datos del usuario a registrar",
                    required = true,
                    content = @Content(schema = @Schema(implementation = RegistroRequest.class))
            )
            @RequestBody Usuario usuario
    ) {
        try {
            Usuario registrado = authService.registrar(usuario);
            return ResponseEntity.ok(registrado);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // =======================
    //         LOGIN
    // =======================
    @Operation(
            summary = "Iniciar sesión",
            description = "Valida credenciales (email y contraseña). Retorna un JSON con message y success. Si falla, retorna 401."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Login exitoso",
                    content = @Content(schema = @Schema(implementation = LoginResponse.class))
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "Credenciales incorrectas",
                    content = @Content(schema = @Schema(implementation = LoginResponse.class))
            )
    })
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Credenciales de inicio de sesión",
                    required = true,
                    content = @Content(schema = @Schema(implementation = LoginRequest.class))
            )
            @RequestBody Usuario usuario
    ) {
        boolean ok = authService.login(usuario.getEmail(), usuario.getContrasena());
        if (ok) {
            return ResponseEntity.ok(Map.of("message", "Login exitoso.", "success", true));
        } else {
            return ResponseEntity.status(401).body(Map.of(
                    "message", "Credenciales incorrectas.",
                    "success", false));
        }
    }

    // =======================
    //    LISTAR TODOS
    // =======================
    @Operation(
            summary = "Listar usuarios",
            description = "Retorna la lista completa de usuarios registrados."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Listado obtenido correctamente",
                    content = @Content(schema = @Schema(implementation = Usuario.class))
            ),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/usuarios")
    public ResponseEntity<List<Usuario>> listarTodos() {
        return ResponseEntity.ok(authService.listarUsuarios());
    }

    // =======================
    // BUSCAR POR CORREO
    // =======================
    @Operation(
            summary = "Buscar usuario por correo",
            description = "Busca un usuario por su correo (email). Si no existe, retorna 404."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario encontrado",
                    content = @Content(schema = @Schema(implementation = Usuario.class))
            ),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @GetMapping("/usuario/correo/{correo}")
    public ResponseEntity<?> buscarUsuarioPorCorreo(
            @Parameter(description = "Correo del usuario", example = "admin@amilimetros.cl")
            @PathVariable String correo
    ) {

        Optional<Usuario> usuario = usuarioRepository.findByEmail(correo);

        if (usuario.isEmpty()) {
            return ResponseEntity.status(404).body("Usuario no encontrado");
        }

        return ResponseEntity.ok(usuario.get());
    }

    // =======================
    //    BUSCAR POR ID
    // =======================
    @Operation(
            summary = "Buscar usuario por ID",
            description = "Busca un usuario por su identificador. Si no existe, retorna 404."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario encontrado",
                    content = @Content(schema = @Schema(implementation = Usuario.class))
            ),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @GetMapping("/usuarios/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "ID del usuario", example = "1")
            @PathVariable Long id
    ) {
        Usuario usuario = authService.buscarPorId(id);
        if (usuario == null) {
            return ResponseEntity.status(404).body("Usuario no encontrado");
        }
        return ResponseEntity.ok(usuario);
    }

    // =======================
    // ACTUALIZAR USUARIO
    // =======================
    @Operation(
            summary = "Actualizar perfil de usuario",
            description = "Actualiza nombre, email y teléfono del usuario. Retorna el usuario actualizado o un error."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario actualizado correctamente",
                    content = @Content(schema = @Schema(implementation = Usuario.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Error de validación o conflicto",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))
            ),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @PutMapping("/usuarios/{id}")
    public ResponseEntity<?> actualizarUsuario(
            @Parameter(description = "ID del usuario", example = "1")
            @PathVariable Long id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Datos de perfil a actualizar",
                    required = true,
                    content = @Content(schema = @Schema(implementation = ActualizarPerfilRequest.class))
            )
            @RequestBody Map<String, String> datos
    ) {
        try {
            String nombre = datos.get("nombre");
            String email = datos.get("email");
            String telefono = datos.get("telefono");

            Usuario actualizado = authService.actualizarPerfil(id, nombre, email, telefono);
            return ResponseEntity.ok(actualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ============================
    // SCHEMAS PARA QUE SWAGGER MUESTRE BIEN LOS BODIES
    // ============================

    @Schema(name = "RegistroRequest", description = "Estructura esperada para registrar un usuario.")
    public static class RegistroRequest {
        @Schema(description = "Nombre completo", example = "Lore Ormeño")
        public String nombre;

        @Schema(description = "Correo electrónico (único)", example = "lore@amilimetros.cl")
        public String email;

        @Schema(description = "Contraseña del usuario", example = "1234")
        public String contrasena;

        @Schema(description = "Teléfono", example = "+56912345678")
        public String telefono;

        @Schema(description = "Rol del usuario (si aplica)", example = "ADMIN")
        public String rol;
    }

    @Schema(name = "LoginRequest", description = "Credenciales para iniciar sesión.")
    public static class LoginRequest {
        @Schema(description = "Correo del usuario", example = "admin@amilimetros.cl", requiredMode = Schema.RequiredMode.REQUIRED)
        public String email;

        @Schema(description = "Contraseña del usuario", example = "1234", requiredMode = Schema.RequiredMode.REQUIRED)
        public String contrasena;
    }

    @Schema(name = "LoginResponse", description = "Respuesta estándar del endpoint de login.")
    public static class LoginResponse {
        @Schema(description = "Mensaje de resultado", example = "Login exitoso.")
        public String message;

        @Schema(description = "Indica si el login fue exitoso", example = "true")
        public Boolean success;
    }

    @Schema(name = "ActualizarPerfilRequest", description = "Body para actualizar datos del perfil del usuario.")
    public static class ActualizarPerfilRequest {
        @Schema(description = "Nombre", example = "Lore Ormeño", requiredMode = Schema.RequiredMode.REQUIRED)
        public String nombre;

        @Schema(description = "Correo", example = "lore@amilimetros.cl", requiredMode = Schema.RequiredMode.REQUIRED)
        public String email;

        @Schema(description = "Teléfono", example = "+56912345678", requiredMode = Schema.RequiredMode.REQUIRED)
        public String telefono;
    }

    @Schema(name = "ErrorResponse", description = "Estructura estándar de error.")
    public static class ErrorResponse {
        @Schema(description = "Mensaje de error", example = "El correo ya está registrado")
        public String error;
    }
}
