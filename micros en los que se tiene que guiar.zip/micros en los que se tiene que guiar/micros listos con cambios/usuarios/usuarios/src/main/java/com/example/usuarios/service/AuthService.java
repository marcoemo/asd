package com.example.usuarios.service;

import java.util.List;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.usuarios.model.Rol;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.repository.RolRepository;
import com.example.usuarios.repository.UsuarioRepository;

@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UsuarioRepository usuarioRepository, RolRepository rolRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.rolRepository = rolRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ============================
    //      REGISTRO USUARIO
    // ============================
    public Usuario registrar(Usuario usuario) {

        if (usuario.getEmail() == null || usuario.getEmail().isBlank()) {
            throw new RuntimeException("El correo es obligatorio");
        }

        if (usuarioRepository.existsByEmail(usuario.getEmail())) {
            throw new RuntimeException("El correo ya está registrado");
        }

        if (usuario.getTelefono() == null || usuario.getTelefono().isBlank()) {
            throw new RuntimeException("El teléfono es obligatorio");
        }

        if (usuarioRepository.existsByTelefono(usuario.getTelefono())) {
            throw new RuntimeException("El teléfono ya está registrado");
        }

        if (usuario.getContrasena() == null || usuario.getContrasena().isBlank()) {
            throw new RuntimeException("La contraseña es obligatoria");
        }

        // ✅ Asignación de rol: si viene null -> USER por defecto.
        // Si viene rol, se valida que sea ADMIN/USER existente en BD.
        Rol rolAsignado;
        if (usuario.getRol() == null || usuario.getRol().getNombre() == null || usuario.getRol().getNombre().isBlank()) {
            rolAsignado = rolRepository.findByNombre("USER")
                    .orElseThrow(() -> new RuntimeException("Rol USER no existe"));
        } else {
            String nombreRol = usuario.getRol().getNombre().toUpperCase();
            if (!nombreRol.equals("ADMIN") && !nombreRol.equals("USER")) {
                throw new RuntimeException("Rol inválido. Solo se permite ADMIN o USER");
            }
            rolAsignado = rolRepository.findByNombre(nombreRol)
                    .orElseThrow(() -> new RuntimeException("Rol " + nombreRol + " no existe"));
        }

        usuario.setRol(rolAsignado);

        // ✅ Se encripta contraseña
        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));

        // isAdmin se sincroniza solo por @PrePersist/@PreUpdate
        return usuarioRepository.save(usuario);
    }

    // ============================
    //         LOGIN
    // ============================
    public boolean login(String email, String contrasenaPlano) {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElse(null);

        if (usuario == null) return false;

        return passwordEncoder.matches(contrasenaPlano, usuario.getContrasena());
    }

    // ============================
    //     LISTAR USUARIOS
    // ============================
    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    // ============================
    //     BUSCAR POR ID
    // ============================
    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    // ============================
    //     ACTUALIZAR PERFIL
    // ============================
    public Usuario actualizarPerfil(Long id, String nombre, String email, String telefono) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        if (nombre == null || nombre.isBlank()) throw new RuntimeException("El nombre no puede estar vacío");
        if (email == null || email.isBlank()) throw new RuntimeException("El email no puede estar vacío");
        if (telefono == null || telefono.isBlank()) throw new RuntimeException("El teléfono no puede estar vacío");

        // Validaciones de duplicado (si cambia)
        if (!email.equalsIgnoreCase(usuario.getEmail()) && usuarioRepository.existsByEmail(email)) {
            throw new RuntimeException("El correo ya está registrado");
        }
        if (!telefono.equalsIgnoreCase(usuario.getTelefono()) && usuarioRepository.existsByTelefono(telefono)) {
            throw new RuntimeException("El teléfono ya está registrado");
        }

        usuario.setNombre(nombre);
        usuario.setEmail(email);
        usuario.setTelefono(telefono);

        return usuarioRepository.save(usuario);
    }
   
}
