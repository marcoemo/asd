package com.example.usuarios.service;

import org.springframework.context.annotation.DependsOn;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.usuarios.model.Rol;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.repository.RolRepository;
import com.example.usuarios.repository.UsuarioRepository;

import jakarta.annotation.PostConstruct;

@Service
@DependsOn("rolInitializer") // asegura que ADMIN/USER ya existen
public class AdminInitializer {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminInitializer(
            UsuarioRepository usuarioRepository,
            RolRepository rolRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.usuarioRepository = usuarioRepository;
        this.rolRepository = rolRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostConstruct
    public void crearAdminInicial() {

        // 🔐 No lo crea si ya existe
        if (usuarioRepository.existsByEmail("admin@amilimetros.cl")) {
            return;
        }

        Rol rolAdmin = rolRepository.findByNombre("ADMIN")
                .orElseThrow(() -> new RuntimeException("Rol ADMIN no existe"));

        Usuario admin = new Usuario();
        admin.setNombre("Admin");
        admin.setEmail("admin@amilimetros.cl");
        admin.setTelefono("+56911111111");
        admin.setContrasena(passwordEncoder.encode("Admin123!"));
        admin.setRol(rolAdmin); // OBLIGATORIO

        usuarioRepository.save(admin);
    }
}
