package com.example.usuarios.service;

import com.example.usuarios.model.Rol;
import com.example.usuarios.repository.RolRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

@Service
public class RolInitializer {

    private final RolRepository rolRepository;

    public RolInitializer(RolRepository rolRepository) {
        this.rolRepository = rolRepository;
    }

    @PostConstruct
    public void initRoles() {
        crearSiNoExiste("ADMIN");
        crearSiNoExiste("USER");
    }

    private void crearSiNoExiste(String nombre) {
        rolRepository.findByNombre(nombre)
                .orElseGet(() -> rolRepository.save(new Rol(null, nombre)));
    }
}
