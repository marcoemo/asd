package com.example.usuarios.service;

import com.example.usuarios.model.Rol;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.repository.RolRepository;
import com.example.usuarios.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class AuthServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private RolRepository rolRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private AuthService authService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    // ==========================
    // REGISTRO - EMAIL VACÍO
    // ==========================
    @Test
    void registrar_falla_siEmailVacio() {
        Usuario u = new Usuario();
        u.setEmail("   ");
        u.setTelefono("12345678");
        u.setContrasena("1234");

        assertThatThrownBy(() -> authService.registrar(u))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("El correo es obligatorio");

        verify(usuarioRepository, never()).save(any());
        verify(rolRepository, never()).findByNombre(anyString());
        verify(passwordEncoder, never()).encode(anyString());
    }

    // ==========================
    // REGISTRO - EMAIL REPETIDO
    // ==========================
    @Test
    void registrar_falla_siEmailRepetido() {
        Usuario u = new Usuario();
        u.setEmail("test@correo.com");
        u.setTelefono("12345678");
        u.setContrasena("1234");

        when(usuarioRepository.existsByEmail("test@correo.com")).thenReturn(true);

        assertThatThrownBy(() -> authService.registrar(u))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("El correo ya está registrado");

        verify(usuarioRepository).existsByEmail("test@correo.com");
        verify(usuarioRepository, never()).save(any());
        verify(rolRepository, never()).findByNombre(anyString());
        verify(passwordEncoder, never()).encode(anyString());
    }

    // ==========================
    // REGISTRO - TELÉFONO VACÍO
    // ==========================
    @Test
    void registrar_falla_siTelefonoVacio() {
        Usuario u = new Usuario();
        u.setEmail("nuevo@correo.com");
        u.setTelefono(" ");
        u.setContrasena("1234");

        when(usuarioRepository.existsByEmail("nuevo@correo.com")).thenReturn(false);

        assertThatThrownBy(() -> authService.registrar(u))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("El teléfono es obligatorio");

        verify(usuarioRepository).existsByEmail("nuevo@correo.com");
        verify(usuarioRepository, never()).save(any());
        verify(rolRepository, never()).findByNombre(anyString());
        verify(passwordEncoder, never()).encode(anyString());
    }

    // ==========================
    // REGISTRO - TELÉFONO REPETIDO
    // ==========================
    @Test
    void registrar_falla_siTelefonoRepetido() {
        Usuario u = new Usuario();
        u.setEmail("nuevo@correo.com");
        u.setTelefono("987654321");
        u.setContrasena("1234");

        when(usuarioRepository.existsByEmail("nuevo@correo.com")).thenReturn(false);
        when(usuarioRepository.existsByTelefono("987654321")).thenReturn(true);

        assertThatThrownBy(() -> authService.registrar(u))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("El teléfono ya está registrado");

        verify(usuarioRepository).existsByEmail("nuevo@correo.com");
        verify(usuarioRepository).existsByTelefono("987654321");
        verify(usuarioRepository, never()).save(any());
        verify(rolRepository, never()).findByNombre(anyString());
        verify(passwordEncoder, never()).encode(anyString());
    }

    // ==========================
    // REGISTRO - CONTRASEÑA VACÍA
    // ==========================
    @Test
    void registrar_falla_siContrasenaVacia() {
        Usuario u = new Usuario();
        u.setEmail("nuevo@correo.com");
        u.setTelefono("987654321");
        u.setContrasena("   ");

        when(usuarioRepository.existsByEmail("nuevo@correo.com")).thenReturn(false);
        when(usuarioRepository.existsByTelefono("987654321")).thenReturn(false);

        assertThatThrownBy(() -> authService.registrar(u))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("La contraseña es obligatoria");

        verify(usuarioRepository, never()).save(any());
        verify(rolRepository, never()).findByNombre(anyString());
        verify(passwordEncoder, never()).encode(anyString());
    }

    // ==========================
    // REGISTRO - ROL INVÁLIDO
    // ==========================
    @Test
    void registrar_falla_siRolInvalido() {
        Usuario u = new Usuario();
        u.setEmail("ok@correo.com");
        u.setTelefono("987654321");
        u.setContrasena("1234");
        u.setRol(new Rol(null, "OTRO"));

        when(usuarioRepository.existsByEmail("ok@correo.com")).thenReturn(false);
        when(usuarioRepository.existsByTelefono("987654321")).thenReturn(false);

        assertThatThrownBy(() -> authService.registrar(u))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("Rol inválido. Solo se permite ADMIN o USER");

        verify(rolRepository, never()).findByNombre(anyString());
        verify(usuarioRepository, never()).save(any());
    }

    // ==========================
    // REGISTRO - OK (por defecto USER)
    // ==========================
    @Test
    void registrar_ok_asignaUSERPorDefecto_encriptaYGuarda() {
        Usuario u = new Usuario();
        u.setNombre("Lore");
        u.setEmail("ok@correo.com");
        u.setTelefono("987654321");
        u.setContrasena("1234");
        u.setRol(null); // fuerza rol por defecto USER

        when(usuarioRepository.existsByEmail("ok@correo.com")).thenReturn(false);
        when(usuarioRepository.existsByTelefono("987654321")).thenReturn(false);

        Rol rolUser = new Rol(2L, "USER");
        when(rolRepository.findByNombre("USER")).thenReturn(Optional.of(rolUser));

        when(passwordEncoder.encode("1234")).thenReturn("ENC_1234");

        when(usuarioRepository.save(any(Usuario.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        Usuario guardado = authService.registrar(u);

        assertThat(guardado.getRol()).isNotNull();
        assertThat(guardado.getRol().getNombre()).isEqualTo("USER");
        assertThat(guardado.getContrasena()).isEqualTo("ENC_1234");

        // isAdmin se sincroniza por @PrePersist/@PreUpdate al persistir; en unit test puro
        // puede no ejecutarse siempre si no pasa por JPA.
        // Igual comprobamos que el rol sea USER (lo importante para permisos).
        verify(rolRepository).findByNombre("USER");
        verify(passwordEncoder).encode("1234");
        verify(usuarioRepository).save(any(Usuario.class));
    }

    // ==========================
    // REGISTRO - OK (rol ADMIN explícito)
    // ==========================
    @Test
    void registrar_ok_conRolADMIN_validaRolYGuarda() {
        Usuario u = new Usuario();
        u.setNombre("Admin");
        u.setEmail("admin@correo.com");
        u.setTelefono("11111111");
        u.setContrasena("1234");
        u.setRol(new Rol(null, "ADMIN"));

        when(usuarioRepository.existsByEmail("admin@correo.com")).thenReturn(false);
        when(usuarioRepository.existsByTelefono("11111111")).thenReturn(false);

        Rol rolAdmin = new Rol(1L, "ADMIN");
        when(rolRepository.findByNombre("ADMIN")).thenReturn(Optional.of(rolAdmin));

        when(passwordEncoder.encode("1234")).thenReturn("ENC_1234");
        when(usuarioRepository.save(any(Usuario.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        Usuario guardado = authService.registrar(u);

        assertThat(guardado.getRol()).isNotNull();
        assertThat(guardado.getRol().getNombre()).isEqualTo("ADMIN");
        assertThat(guardado.getContrasena()).isEqualTo("ENC_1234");

        verify(rolRepository).findByNombre("ADMIN");
        verify(passwordEncoder).encode("1234");
        verify(usuarioRepository).save(any(Usuario.class));
    }

    // ==========================
    // LOGIN - usuario no existe
    // ==========================
    @Test
    void login_false_siUsuarioNoExiste() {
        when(usuarioRepository.findByEmail("no@existe.cl")).thenReturn(Optional.empty());

        boolean ok = authService.login("no@existe.cl", "1234");

        assertThat(ok).isFalse();
        verify(passwordEncoder, never()).matches(anyString(), anyString());
    }

    // ==========================
    // LOGIN - ok
    // ==========================
    @Test
    void login_true_siPasswordMatches() {
        Usuario u = new Usuario();
        u.setEmail("user@correo.cl");
        u.setContrasena("HASH");

        when(usuarioRepository.findByEmail("user@correo.cl")).thenReturn(Optional.of(u));
        when(passwordEncoder.matches("1234", "HASH")).thenReturn(true);

        boolean ok = authService.login("user@correo.cl", "1234");

        assertThat(ok).isTrue();
        verify(passwordEncoder).matches("1234", "HASH");
    }

    // ==========================
    // LOGIN - incorrecto
    // ==========================
    @Test
    void login_false_siPasswordNoMatches() {
        Usuario u = new Usuario();
        u.setEmail("user@correo.cl");
        u.setContrasena("HASH");

        when(usuarioRepository.findByEmail("user@correo.cl")).thenReturn(Optional.of(u));
        when(passwordEncoder.matches("1234", "HASH")).thenReturn(false);

        boolean ok = authService.login("user@correo.cl", "1234");

        assertThat(ok).isFalse();
        verify(passwordEncoder).matches("1234", "HASH");
    }
}
