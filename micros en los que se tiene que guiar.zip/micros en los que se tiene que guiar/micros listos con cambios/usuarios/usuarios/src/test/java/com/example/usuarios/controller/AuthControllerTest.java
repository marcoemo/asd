package com.example.usuarios.controller;

import com.example.usuarios.model.Rol;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.repository.UsuarioRepository;
import com.example.usuarios.service.AuthService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthService authService;

    @MockBean
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ObjectMapper objectMapper;

    // =========================================================
    // REGISTER
    // =========================================================

    @Test
    void register_ok_retorna200_yUsuario() throws Exception {
        Usuario req = new Usuario();
        req.setNombre("Lore");
        req.setEmail("lore@correo.cl");
        req.setTelefono("12345678");
        req.setContrasena("1234");

        Usuario resp = new Usuario();
        resp.setId(1L);
        resp.setNombre("Lore");
        resp.setEmail("lore@correo.cl");
        resp.setTelefono("12345678");
        resp.setContrasena("ENC");
        resp.setRol(new Rol(2L, "USER"));
        resp.setIsAdmin(false);

        when(authService.registrar(any(Usuario.class))).thenReturn(resp);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.email").value("lore@correo.cl"));

        verify(authService).registrar(any(Usuario.class));
    }

    @Test
    void register_error_retorna400_conMensaje() throws Exception {
        Usuario req = new Usuario();
        req.setEmail("duplicado@correo.cl");
        req.setTelefono("12345678");
        req.setContrasena("1234");

        when(authService.registrar(any(Usuario.class)))
                .thenThrow(new RuntimeException("El correo ya está registrado"));

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("El correo ya está registrado"));

        verify(authService).registrar(any(Usuario.class));
    }

    // =========================================================
    // LOGIN
    // =========================================================

    @Test
    void login_ok_retorna200_conSuccessTrue() throws Exception {
        Usuario req = new Usuario();
        req.setEmail("admin@correo.cl");
        req.setContrasena("1234");

        when(authService.login("admin@correo.cl", "1234")).thenReturn(true);

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Login exitoso."));

        verify(authService).login("admin@correo.cl", "1234");
    }

    @Test
    void login_fail_retorna401_conSuccessFalse() throws Exception {
        Usuario req = new Usuario();
        req.setEmail("admin@correo.cl");
        req.setContrasena("mala");

        when(authService.login("admin@correo.cl", "mala")).thenReturn(false);

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Credenciales incorrectas."));

        verify(authService).login("admin@correo.cl", "mala");
    }

    // =========================================================
    // LISTAR USUARIOS
    // =========================================================

    @Test
    void listarUsuarios_ok_retorna200_yLista() throws Exception {
        Usuario u1 = new Usuario();
        u1.setId(1L);
        u1.setEmail("a@a.cl");
        u1.setRol(new Rol(2L, "USER"));
        u1.setIsAdmin(false);

        Usuario u2 = new Usuario();
        u2.setId(2L);
        u2.setEmail("b@b.cl");
        u2.setRol(new Rol(1L, "ADMIN"));
        u2.setIsAdmin(true);

        when(authService.listarUsuarios()).thenReturn(List.of(u1, u2));

        mockMvc.perform(get("/auth/usuarios"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].email").value("a@a.cl"))
                .andExpect(jsonPath("$[1].email").value("b@b.cl"));

        verify(authService).listarUsuarios();
    }

    // =========================================================
    // BUSCAR POR CORREO 
    // =========================================================

    @Test
    void buscarPorCorreo_ok_retorna200() throws Exception {
        Usuario u = new Usuario();
        u.setId(5L);
        u.setEmail("user@correo.cl");
        u.setRol(new Rol(2L, "USER"));
        u.setIsAdmin(false);

        when(usuarioRepository.findByEmail("user@correo.cl"))
                .thenReturn(Optional.of(u));

        mockMvc.perform(get("/auth/usuario/correo/{correo}", "user@correo.cl"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(5))
                .andExpect(jsonPath("$.email").value("user@correo.cl"))
                .andExpect(jsonPath("$.isAdmin").value(false));

        verify(usuarioRepository).findByEmail("user@correo.cl");
    }

    @Test
    void buscarPorCorreo_noExiste_retorna404() throws Exception {
        when(usuarioRepository.findByEmail("no@existe.cl"))
                .thenReturn(Optional.empty());

        mockMvc.perform(get("/auth/usuario/correo/{correo}", "no@existe.cl"))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Usuario no encontrado"));

        verify(usuarioRepository).findByEmail("no@existe.cl");
    }

    // =========================================================
    // BUSCAR POR ID
    // =========================================================

    @Test
    void buscarPorId_ok_retorna200() throws Exception {
        Usuario u = new Usuario();
        u.setId(10L);
        u.setEmail("x@x.cl");
        u.setRol(new Rol(2L, "USER"));
        u.setIsAdmin(false);

        when(authService.buscarPorId(10L)).thenReturn(u);

        mockMvc.perform(get("/auth/usuarios/{id}", 10L))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(10))
                .andExpect(jsonPath("$.email").value("x@x.cl"));

        verify(authService).buscarPorId(10L);
    }

    @Test
    void buscarPorId_noExiste_retorna404() throws Exception {
        when(authService.buscarPorId(999L)).thenReturn(null);

        mockMvc.perform(get("/auth/usuarios/{id}", 999L))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Usuario no encontrado"));

        verify(authService).buscarPorId(999L);
    }

    // =========================================================
    // ACTUALIZAR PERFIL
    // =========================================================

    @Test
    void actualizarUsuario_ok_retorna200() throws Exception {
        Long id = 7L;

        Map<String, String> req = Map.of(
                "nombre", "Lore",
                "email", "lore@correo.cl",
                "telefono", "12345678"
        );

        Usuario actualizado = new Usuario();
        actualizado.setId(id);
        actualizado.setNombre("Lore");
        actualizado.setEmail("lore@correo.cl");
        actualizado.setTelefono("12345678");
        actualizado.setRol(new Rol(2L, "USER"));
        actualizado.setIsAdmin(false);

        when(authService.actualizarPerfil(eq(id), eq("Lore"), eq("lore@correo.cl"), eq("12345678")))
                .thenReturn(actualizado);

        mockMvc.perform(put("/auth/usuarios/{id}", id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(7))
                .andExpect(jsonPath("$.email").value("lore@correo.cl"));

        verify(authService).actualizarPerfil(id, "Lore", "lore@correo.cl", "12345678");
    }

    @Test
    void actualizarUsuario_error_retorna400_conJsonError() throws Exception {
        Long id = 7L;

        Map<String, String> req = Map.of(
                "nombre", "Lore",
                "email", "duplicado@correo.cl",
                "telefono", "12345678"
        );

        when(authService.actualizarPerfil(eq(id), anyString(), anyString(), anyString()))
                .thenThrow(new RuntimeException("El correo ya está registrado"));

        mockMvc.perform(put("/auth/usuarios/{id}", id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("El correo ya está registrado"));

        verify(authService).actualizarPerfil(eq(id), eq("Lore"), eq("duplicado@correo.cl"), eq("12345678"));
    }
}
